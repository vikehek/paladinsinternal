# BlueFirePaladinsHack
External hack for Paladins using Mhyprot to read and write memory and nvidia hijack for overlay

https://github.com/leeza007/evil-mhyprot-cli

https://github.com/iraizo/nvidia-overlay-hijack

(Nvidia overlay is not required but recommended as it will just create a transparent window if not found)

Includes:
+ Aimbot (lock and smooth)
+ BoxEPS, Name and HP
+ Tracers
+ NoRecoil + NoSpread
+ ThirdPerson
+ Glow
